// ============================================================
// nexus-orchestrator.ts
// Orquestrador principal do Nexus
// Aciona múltiplas IAs em paralelo e funde as respostas
// ============================================================

import Anthropic from "@anthropic-ai/sdk";

// ── Tipos ────────────────────────────────────────────────────

export type AgentName = "claude" | "codex" | "antygravit" | "vis";

export interface AgentConfig {
  name: AgentName;
  enabled: boolean;
  timeout: number; // ms
  role: string;    // instrução de sistema específica por IA
}

export interface AgentResult {
  agent: AgentName;
  content: string;
  tokens: number;
  latency: number;
  ok: boolean;
  error?: string;
}

export interface OrchestratorResponse {
  merged: string;           // resposta fundida final
  agents: AgentResult[];    // respostas individuais de cada IA
  totalLatency: number;
  activeAgents: number;
}

export interface OrchestratorRequest {
  prompt: string;
  agents?: AgentName[];     // quais IAs usar (default: todas ativas)
  context?: string;         // contexto do projeto/arquivo atual
  language?: string;        // linguagem do editor (typescript, python, etc)
}

// ── Configuração dos agentes ─────────────────────────────────

const AGENT_CONFIGS: Record<AgentName, AgentConfig> = {
  claude: {
    name: "claude",
    enabled: true,
    timeout: 15000,
    role: `Você é o agente de raciocínio do Nexus, uma plataforma de programação multi-IA.
Foque em: explicar decisões de arquitetura, revisar lógica, sugerir melhorias de design.
Seja conciso e direto. Responda sempre em português.`,
  },
  codex: {
    name: "codex",
    enabled: true,
    timeout: 15000,
    role: `Você é o agente de geração de código do Nexus.
Foque em: gerar código limpo e funcional, completar funções, corrigir bugs, escrever testes.
Sempre inclua o código completo, sem omissões. Responda em português com código em inglês.`,
  },
  antygravit: {
    name: "antygravit",
    enabled: true,
    timeout: 15000,
    role: `Você é o agente de otimização do Nexus.
Foque em: performance, segurança, edge cases, refatoração. Pense diferente dos outros agentes.
Questione suposições e proponha alternativas inesperadas. Responda em português.`,
  },
  vis: {
    name: "vis",
    enabled: false,
    timeout: 15000,
    role: `Você é o agente visual do Nexus.
Foque em: componentes de UI, CSS, acessibilidade, experiência do usuário.
Gere código de componentes completos. Responda em português.`,
  },
};

// ── Cliente Anthropic ─────────────────────────────────────────

const client = new Anthropic();
// A API key é lida automaticamente de process.env.ANTHROPIC_API_KEY

// ── Funções auxiliares ────────────────────────────────────────

function withTimeout<T>(promise: Promise<T>, ms: number, agent: AgentName): Promise<T> {
  const timeout = new Promise<never>((_, reject) =>
    setTimeout(() => reject(new Error(`Timeout após ${ms}ms`)), ms)
  );
  return Promise.race([promise, timeout]);
}

// Cada agente usa o mesmo modelo mas com system prompt diferente
// Em produção, "codex" e "antygravit" apontariam para APIs distintas
async function callAgent(
  agent: AgentName,
  prompt: string,
  context?: string,
  language?: string
): Promise<{ text: string; tokens: number }> {
  const config = AGENT_CONFIGS[agent];

  const systemPrompt = [
    config.role,
    context ? `\nContexto atual do projeto:\n${context}` : "",
    language ? `\nLinguagem ativa no editor: ${language}` : "",
  ]
    .filter(Boolean)
    .join("\n");

  const response = await client.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 1024,
    system: systemPrompt,
    messages: [{ role: "user", content: prompt }],
  });

  const text =
    response.content
      .filter((b) => b.type === "text")
      .map((b) => (b as { type: "text"; text: string }).text)
      .join("") || "";

  return {
    text,
    tokens: response.usage.input_tokens + response.usage.output_tokens,
  };
}

// ── Fusão das respostas ───────────────────────────────────────

function mergeResponses(results: AgentResult[], prompt: string): string {
  const successful = results.filter((r) => r.ok);

  if (successful.length === 0) {
    return "Nenhuma IA conseguiu responder. Tente novamente.";
  }

  if (successful.length === 1) {
    return successful[0].content;
  }

  // Estratégia de fusão: identifica código nas respostas e prioriza
  const hasCode = (text: string) =>
    text.includes("```") || text.includes("function ") || text.includes("const ");

  const codeAgents = successful.filter((r) => hasCode(r.content));
  const textAgents = successful.filter((r) => !hasCode(r.content));

  const sections: string[] = [];

  // Agentes com código vêm primeiro
  if (codeAgents.length > 0) {
    codeAgents.forEach((r) => {
      sections.push(`**[${r.agent.toUpperCase()}]** _(${r.latency}ms)_\n${r.content}`);
    });
  }

  // Depois os agentes com análise/texto
  if (textAgents.length > 0) {
    textAgents.forEach((r) => {
      sections.push(`**[${r.agent.toUpperCase()}]** _(${r.latency}ms)_\n${r.content}`);
    });
  }

  return sections.join("\n\n---\n\n");
}

// ── Orquestrador principal ────────────────────────────────────

export async function orchestrate(
  req: OrchestratorRequest
): Promise<OrchestratorResponse> {
  const startTime = Date.now();

  // Quais agentes usar
  const agentsToRun = (req.agents ?? (Object.keys(AGENT_CONFIGS) as AgentName[])).filter(
    (a) => AGENT_CONFIGS[a].enabled
  );

  if (agentsToRun.length === 0) {
    return {
      merged: "Nenhuma IA ativa. Ative pelo menos uma IA no painel.",
      agents: [],
      totalLatency: 0,
      activeAgents: 0,
    };
  }

  // Dispara todas as IAs em paralelo
  const tasks = agentsToRun.map(async (agent): Promise<AgentResult> => {
    const t0 = Date.now();
    try {
      const { text, tokens } = await withTimeout(
        callAgent(agent, req.prompt, req.context, req.language),
        AGENT_CONFIGS[agent].timeout,
        agent
      );
      return {
        agent,
        content: text,
        tokens,
        latency: Date.now() - t0,
        ok: true,
      };
    } catch (err) {
      return {
        agent,
        content: "",
        tokens: 0,
        latency: Date.now() - t0,
        ok: false,
        error: err instanceof Error ? err.message : "Erro desconhecido",
      };
    }
  });

  // Aguarda todas (com allSettled para não cancelar se uma falhar)
  const settled = await Promise.allSettled(tasks);
  const agents: AgentResult[] = settled.map((s) =>
    s.status === "fulfilled"
      ? s.value
      : {
          agent: "claude" as AgentName,
          content: "",
          tokens: 0,
          latency: 0,
          ok: false,
          error: "Falha inesperada",
        }
  );

  const merged = mergeResponses(agents, req.prompt);

  return {
    merged,
    agents,
    totalLatency: Date.now() - startTime,
    activeAgents: agents.filter((a) => a.ok).length,
  };
}

// ── Utilitários de configuração ───────────────────────────────

export function enableAgent(name: AgentName) {
  AGENT_CONFIGS[name].enabled = true;
}

export function disableAgent(name: AgentName) {
  AGENT_CONFIGS[name].enabled = false;
}

export function setAgentTimeout(name: AgentName, ms: number) {
  AGENT_CONFIGS[name].timeout = ms;
}

export function getAgentStatus(): Record<AgentName, boolean> {
  return Object.fromEntries(
    Object.entries(AGENT_CONFIGS).map(([k, v]) => [k, v.enabled])
  ) as Record<AgentName, boolean>;
}

// ── Demo / teste rápido ───────────────────────────────────────

async function demo() {
  console.log("🔷 Nexus Orchestrator — iniciando demo\n");

  const request: OrchestratorRequest = {
    prompt: "Crie uma função TypeScript que faz retry automático de uma Promise com backoff exponencial",
    agents: ["claude", "codex"],
    language: "typescript",
    context: "Projeto: nexus-app. Arquivo atual: api.ts",
  };

  console.log(`📨 Prompt: "${request.prompt}"`);
  console.log(`🤖 Agentes: ${request.agents?.join(", ")}\n`);

  try {
    const result = await orchestrate(request);

    console.log(`✅ Concluído em ${result.totalLatency}ms — ${result.activeAgents} IAs responderam\n`);
    console.log("─".repeat(60));

    result.agents.forEach((r) => {
      if (r.ok) {
        console.log(`\n🟢 ${r.agent.toUpperCase()} (${r.latency}ms, ${r.tokens} tokens)`);
        console.log(r.content.slice(0, 300) + (r.content.length > 300 ? "..." : ""));
      } else {
        console.log(`\n🔴 ${r.agent.toUpperCase()} — ERRO: ${r.error}`);
      }
    });

    console.log("\n" + "─".repeat(60));
    console.log("\n🔀 RESPOSTA FUNDIDA:\n");
    console.log(result.merged);
  } catch (err) {
    console.error("Erro no orquestrador:", err);
  }
}

demo();
